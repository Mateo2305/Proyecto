<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\citas_pacientesController;
use App\Http\Controllers\pacientesController;
use App\Http\Controllers\personalController;
use App\Http\Controllers\citasController;
use App\Http\Controllers\expedienteController;
use App\Http\Controllers\AuthController;
use App\Models\expediente;



Route::post('login', 'App\Http\Controllers\AuthController@login');
Route::post('register', 'App\Http\Controllers\AuthController@register');
Route::post('logout', 'App\Http\Controllers\AuthController@logout');
Route::post('refresh', 'App\Http\Controllers\AuthController@refresh');
Route::post('me', 'App\Http\Controllers\AuthController@me');

Route::get('/citas',[citasController::class,'getcitas']);
Route::get('/citas/{id}',[citasController::class,'getcitasid']);
Route::get('/citas_pacientes',[citas_pacientesController::class,'getcitas_pacientes']);
Route::get('/citas_pacientes/{id}',[citas_pacientesController::class,'getcitas_pacientesid']);
Route::get('/pacientes',[pacientesController::class,'getpacientes']);
Route::get('/pacientes/{id}',[pacientesController::class,'getpacientesid']);
Route::get('/expediente',[expedienteController::class,'getexpediente']);
Route::get('/expediente/{id}',[expedienteController::class,'getexpedienteid']);
Route::get('/personal',[personalController::class,'getpersonal']);
Route::get('/personal/{id}',[PersonalController::class,'getpersonalid']);

//post
Route::post('/citas_pacientes/insert',[citas_pacientesController::class,'insertcitas_pacientes']);
Route::post('/citas/insert',[citasController::class,'insertcitas']);
Route::post('/pacientes/insert',[pacientesController::class,'insertpacientes']);
Route::post('/expediente/insert',[expedienteController::class,'insertexpediente']);
Route::post('/personal/insert',[personalController::class,'insertpersonal']);

//put
Route::put('/citas_pacientes/update/{id}',[citas_pacientesController::class,'updatecitas_pacientes']);
Route::put('/citas/update/{id}',[citasController::class,'updatecitas']);
Route::put('/expediente/update/{id}',[expedienteController::class,'updateexpediente']);
Route::put('/pacientes/update/{id}',[pacientesController::class,'updatepacientes']);
Route::put('/personal/update/{id}',[personalController::class,'updatepersonal']);

//delete
Route::delete('/citas_pacientes/delete/{id}',[Citas_pacientesController::class,'deletecitas_pacientes']);
Route::delete('/expediente/delete/{id}',[expedienteController::class,'deleteexpediente']);
Route::delete('/citas/delete/{id}',[citasController::class,'deletecitas']);
Route::delete('/pacientes/delete/{id}',[PacientesController::class,'deletepacientes']);
Route::delete('/personal/delete/{id}',[PersonalController::class,'deletepersonal']);


