<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class citas_pacientes extends Model
{
    use HasFactory;
    public $timestamps =false;
    protected $table ='citas_pacientes';
    protected $fillable=['id_citas_pacientes','id_cita','id_personal','id_paciente','id_usuario','motivo_movimiento','status_movimiento',
    'fecha_creado','status'];
}