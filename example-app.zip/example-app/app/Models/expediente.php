<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class expediente extends Model
{
    use HasFactory;
    public $timestamps =false;
    protected $table ='expediente_clinico';
    protected $fillable=['id_expediente_clinico','num_expediente','nombre','edad','sexo','domicilio','telefono','duracion','semanas','antecedentes_patologicos',
'enfermedades_previas','antecedentes_heredofamiliares','sintomas_ult_anio','intervenciones_quiru','fecha_intervencion',
'tipo_intervencion','embarazo','tratamiento_previo','mejoria','descripcion_padecimiento','diagnostico','plan_tratamiento','recomendaciones',
'consentimiento','escala_eva','descripcion_eva','ft','cedula'];
    
}