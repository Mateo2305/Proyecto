<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class pacientes extends Model
{
    use HasFactory;
    public $timestamps =false;
    protected $table ='pacientes';
    protected $fillable=['id_paciente','no_expediente','nombre','apellido_paterno','apellido_materno','edad'
    ,'sexo','domicilio','telefono_celular_1','telefono_celular_2','telefono_casa','email'
    ,'fecha_nacimiento','tipo_sanguineo','fecha_alta','fecha_Modificacion','fecha_baja','status','id_usuario',
    'id_personal'];
    
}

