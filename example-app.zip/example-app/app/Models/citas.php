<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class citas extends Model
{
    use HasFactory;
    public $timestamps =false;
    protected $table ='citas';
    protected $fillable=['id_cita','id_cita_encargado','Servicio','capacidad','fecha_inicio',
    'fecha_final','status','motivo_movimiento','bloqueo','id_usuario_bloqueo','fecha_Modificacion','fecha_creado','id_usuario'];
}
