<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class personal extends Model
{
    use HasFactory;
    public $timestamps =false;
    protected $table ='personal';
    protected $fillable=['id_personal','status','nombre','id_especialidad','id_puesto','cedula','telefono','id_cubiculo','fecha_creacion',
    'id_usuario_alta','fecha_alta','id_usuario_baja','fecha_baja','personal_id_usuario'];
}