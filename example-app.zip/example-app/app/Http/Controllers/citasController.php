<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\citas;

class citasController extends Controller
{
    //
    public function getcitas()
    {
        return response()->json(citas::all(), 200);
    }

    public function getcitasid($id)
    {
        //$pacientes = pacientes::find($id);
        $citas = citas::where('id_cita', $id)->first();
        return response()->json($citas, 200);
    }

    public function insertcitas(Request $request)
    {
        $citas = citas::create($request->all());
        if (is_null($citas)) {
            return response()->json(["message" => "Hubo problemas al registrar"], 404);
        }
        return response()->json($citas, 200);

        $result = [
            'result' => 1,
            'data' => $citas
        ];
        return response()->json($result, 200);
    }

    public function updatecitas(Request $request, $id)
    {
        $citas = citas::find($id);
        if (is_null($citas)) {
            return response()->json(["message" => "Registro no encontrado"], 404);
        }
        $citas->update($request->all());
        return response()->json($citas, 200);
    }

    public function deletecitas($id)
    {
        $citas =citas::find($id);
        if (is_null($citas)) {
            return response()->json(["message" => "Registro no encontrado"], 404);
        }
        $citas->delete();
        return response()->json(["message" => "Registro eliminado"], 200);
    }
}

