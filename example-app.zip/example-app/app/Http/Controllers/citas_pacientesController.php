<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\citas_pacientes;

class citas_pacientesController extends Controller
{
    //
    public function getcitas_pacientes(){
        return response()->json(citas_pacientes::all(),200);

    }

    public function getcitas_pacientesid($id)
    {
        //$pacientes = pacientes::find($id);
        $citas_pacientes = citas_pacientes::where('id_cita', $id)->first();
        return response()->json($citas_pacientes, 200);
    }

    
    public function insertcitas_pacientes(Request $request){
        $citas_pacientes= citas_pacientes::create($request->all());
        if(is_null($citas_pacientes)){
            return response()->json(["message"=>"Hubo problemas al registrar"],404);
        }
        return response()->json($citas_pacientes,200);
        $result = [
            'result' => 1,
            'data' => $citas_pacientes
        ];
        return response()->json($result,200);
    }

    public function updatecitas_pacientes(Request $request,$id){
        $citas_pacientes = citas_pacientes::find($id);
        if(is_null($citas_pacientes)){
            return response()->json(["message"=>"Registro no encontrado"], 404);
        }
        $citas_pacientes->update($request->all());
        return response()->json($citas_pacientes,200);
    }

    public function deletecitas_pacientes($id){
        $citas_pacientes = citas_pacientes::find($id);
        if(is_null($citas_pacientes)){
            return response()->json(["message"=>"Registro no encontrado"], 404);
    }
    $citas_pacientes->delete();
    return response()->json(["message"=>"Registro eliminado"],200);
}
}