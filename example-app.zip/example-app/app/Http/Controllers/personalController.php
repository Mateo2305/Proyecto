<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\personal;

class personalController extends Controller
{
    //
    public function getpersonal(){
        return response()->json(personal::all(),200);

    }

    public function getpersonalid($id){
    //$personal = personal::find($id);
    $personal = personal::where('id_personal', $id)->first();
    return response()->json($personal, 200);
    }
    
    public function insertpersonal(Request $request){
        $personal= personal::create($request->all());
        if(is_null($personal)){
            return response()->json(["message"=>"Hubo problemas al registrar"],404);
        }
        return response()->json($personal,200);
    }

    public function updatepersonal(Request $request,$id){
        $personal = personal::find($id);
        if(is_null($personal)){
            return response()->json(["message"=>"Registro no encontrado"], 404);
        }
        $personal->update($request->all());
        return response()->json($personal,200);
    }

    public function deletepersonal($id){
        $personal = personal::find($id);
        if(is_null($personal)){
            return response()->json(["message"=>"Registro no encontrado"], 404);
    }
    $personal->delete();
    return response()->json(["message"=>"Registro eliminado"],200);
}
}
