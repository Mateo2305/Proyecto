<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\pacientes;

class pacientesController extends Controller
{
    //
    public function getpacientes()
    {
        return response()->json(pacientes::all(), 200);
    }

    public function getpacientesid($id)
    {
        //$pacientes = pacientes::find($id);
        $pacientes = pacientes::where('id_paciente', $id)->first();
        return response()->json($pacientes, 200);
    }

    public function insertpacientes(Request $request)
    {
        $pacientes = pacientes::create($request->all());
        if (is_null($pacientes)) {
            return response()->json(["message" => "Hubo problemas al registrar"], 404);
        }
        return response()->json($pacientes, 200);

        $result = [
            'result' => 1,
            'data' => $pacientes
        ];
        return response()->json($result, 200);
    }

    public function updatepacientes(Request $request, $id)
    {
        $pacientes = pacientes::find($id);
        if (is_null($pacientes)) {
            return response()->json(["message" => "Registro no encontrado"], 404);
        }
        $pacientes->update($request->all());
        return response()->json($pacientes, 200);
    }

    public function deletepacientes($id)
    {
        $pacientes = pacientes::find($id);
        if (is_null($pacientes)) {
            return response()->json(["message" => "Registro no encontrado"], 404);
        }
        $pacientes->delete();
        return response()->json(["message" => "Registro eliminado"], 200);
    }
}
