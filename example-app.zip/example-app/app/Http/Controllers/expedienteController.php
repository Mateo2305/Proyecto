<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\expediente;

class expedienteController extends Controller
{
    //
    public function getexpediente()
    {
        return response()->json(expediente::all(), 200);
    }

    public function getexpedienteid($id)
    {
        //$pacientes = pacientes::find($id);
        $expediente = expediente::where('id_expediente_clinico', $id)->first();
        return response()->json($expediente, 200);
    }

    public function insertexpediente(Request $request)
    {
        $expediente = expediente::create($request->all());
        if (is_null($expediente)) {
            return response()->json(["message" => "Hubo problemas al registrar"], 404);
        }
        return response()->json($expediente, 200);

        $result = [
            'result' => 1,
            'data' => $expediente
        ];
        return response()->json($result, 200);
    }

    public function updateexpediente(Request $request, $id)
    {
        $expediente = expediente::find($id);
        if (is_null($expediente)) {
            return response()->json(["message" => "Registro no encontrado"], 404);
        }
        $expediente->update($request->all());
        return response()->json($expediente, 200);
    }

    public function deleteexpediente($id)
    {
        $expediente = expediente::find($id);
        if (is_null($expediente)) {
            return response()->json(["message" => "Registro no encontrado"], 404);
        }
        $expediente->delete();
        return response()->json(["message" => "Registro eliminado"], 200);
    }
}
